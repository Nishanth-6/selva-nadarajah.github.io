---
title: Teaching
description: Teaching and courses.
---

This is placeholder copy for the Teaching intro. Replace with the same meaning as the existing teaching.html, but structured for readability.
