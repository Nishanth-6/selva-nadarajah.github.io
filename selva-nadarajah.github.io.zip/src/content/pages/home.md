---
title: Selva Nadarajah
description: Academic homepage.
---

This is placeholder copy for Home. Replace with the content from the existing site, rewritten for readability.

Contact
- Email: replace@university.edu

Affiliations
- Replace institution(s) and department(s)

Research areas
- Self-adapting approximations
- Energy real options
- Energy and computing nexus
