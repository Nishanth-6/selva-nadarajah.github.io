---
title: Curriculum Vitae
description: Curriculum vitae.
---

Download the CV: [NadarajahCV.pdf](/NadarajahCV.pdf)

Optional summary
- Add bullets here later.
